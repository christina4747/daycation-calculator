import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from "recharts";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import Logo from "./daycation-logo.svg";

const sampleMonthly = [
  { month: 'Jan', revenue: 1200, adr: 95 },
  { month: 'Feb', revenue: 1500, adr: 110 },
  { month: 'Mar', revenue: 1800, adr: 120 },
  { month: 'Apr', revenue: 2200, adr: 140 },
  { month: 'May', revenue: 3200, adr: 200 },
  { month: 'Jun', revenue: 4200, adr: 260 },
  { month: 'Jul', revenue: 5000, adr: 300 },
  { month: 'Aug', revenue: 4500, adr: 280 },
  { month: 'Sep', revenue: 3300, adr: 210 },
  { month: 'Oct', revenue: 2100, adr: 150 },
  { month: 'Nov', revenue: 1700, adr: 120 },
  { month: 'Dec', revenue: 1900, adr: 130 },
];

export default function App() {
  const [address, setAddress] = useState("");
  const [beds, setBeds] = useState(1);
  const [baths, setBaths] = useState(1);
  const [guests, setGuests] = useState(2);
  const [longTermRent, setLongTermRent] = useState("");
  const [listingType, setListingType] = useState("Furnished");
  const [currency, setCurrency] = useState("USD");
  const [radius, setRadius] = useState(10);

  const [adr, setAdr] = useState(150);
  const [occupancy, setOccupancy] = useState(60);
  const [managementFee, setManagementFee] = useState(20);
  const [monthlyResult, setMonthlyResult] = useState(null);

  function calculateIncome() {
    const gross = Number(adr) * (Number(occupancy) / 100) * 30;
    const net = gross - (gross * (Number(managementFee) / 100));
    setMonthlyResult(Number(net.toFixed(2)));
  }

  async function downloadPdf() {
    const node = document.getElementById("report");
    const canvas = await html2canvas(node, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save("daycation-report.pdf");
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <img src={Logo} alt="Daycation" className="logo" />
        <h1>New Report</h1>
        <label>Address</label>
        <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Enter property address" />

        <div className="row">
          <div>
            <label>Beds</label>
            <input type="number" value={beds} onChange={e => setBeds(e.target.value)} min="0" />
          </div>
          <div>
            <label>Baths</label>
            <input type="number" value={baths} onChange={e => setBaths(e.target.value)} min="0" />
          </div>
          <div>
            <label>Guests</label>
            <input type="number" value={guests} onChange={e => setGuests(e.target.value)} min="1" />
          </div>
        </div>

        <label>Long-term Monthly Rent</label>
        <input value={longTermRent} onChange={e => setLongTermRent(e.target.value)} placeholder="e.g. 3900" />

        <label>Listing Type</label>
        <select value={listingType} onChange={e => setListingType(e.target.value)}>
          <option>Furnished</option>
          <option>Unfurnished</option>
        </select>

        <label>Currency</label>
        <input value={currency} onChange={e => setCurrency(e.target.value)} />

        <label>Radius (miles)</label>
        <input type="number" value={radius} onChange={e => setRadius(e.target.value)} />

        <button className="gold" onClick={() => { calculateIncome(); }}>Create Report</button>
      </aside>

      <main className="main">
        <div id="report" className="report">
          <header className="report-head">
            <h2>Property Report</h2>
            <div className="summary">
              <div><strong>Estimated Monthly Net</strong><div>${monthlyResult ?? "—"}</div></div>
              <div><strong>Avg Daily Rate</strong><div>${adr}</div></div>
              <div><strong>Occupancy</strong><div>{occupancy}%</div></div>
            </div>
          </header>

          <section className="charts">
            <div className="chart-card">
              <h3>Monthly Revenue</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={sampleMonthly}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="chart-card">
              <h3>Average Daily Rate</h3>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={sampleMonthly}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="adr" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>

        <div className="actions">
          <button onClick={downloadPdf}>Download Report PDF</button>
        </div>
      </main>
    </div>
  );
}