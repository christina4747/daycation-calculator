Daycation Income Estimator - Vite + React
Quick start (local):
1. npm install
2. npm run dev
3. Open http://localhost:5173

This sample includes Recharts, jsPDF and html2canvas for PDF export.
Replace sample data in src/App.jsx with real data-fetching logic (InsideAirbnb, etc.).
